//
//  FoldingCell.h
//  FoldingCell
//
//  Created by Alex K. on 02/06/16.
//  Copyright © 2016 Alex K. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FoldingCell.
FOUNDATION_EXPORT double FoldingCellVersionNumber;

//! Project version string for FoldingCell.
FOUNDATION_EXPORT const unsigned char FoldingCellVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FoldingCell/PublicHeader.h>


