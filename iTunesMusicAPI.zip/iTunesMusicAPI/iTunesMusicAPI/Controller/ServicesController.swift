//
//  ServicesController.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by ADMIN on 10/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit

class ServicesController: NSObject {
    // Can't init is singleton
    private override init() { }
    
    // MARK: Shared Instance
    static let shared = ServicesController()
    
    // MARK: Get Order API
    func GetSearchedEntityRecords(parameter:[String:Any]!, andURL url: String, completion: @escaping (Any?) -> Void) {
        print(parameter)
        Services.shared.getAPIIntegrationWithGetMethod(parameters: parameter, andUrl: url) { (resultResponce) in
            
            if resultResponce is ServiceConstant.GeneralError {
                
                Toast.init(text: StringConstant.TRY_LATER).show()
                completion(ServiceConstant.GeneralError.NoDataFound)
            }
            else if resultResponce is Error{
                completion(ServiceConstant.Error.NoInternet)
            }else{
                let responseDict = resultResponce as! NSDictionary
                
                if responseDict.count > 0 {
                    completion(responseDict)
                } else {
                    completion(ServiceConstant.GeneralError.NoDataFound)
                }
            }
            
        }
    }
}
