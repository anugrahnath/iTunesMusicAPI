//
//  EntityResultModel.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by ADMIN on 10/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import Foundation


class EntityResultModel : NSObject, NSCoding{
    
    var artistId : Int!
    var artistName : String!
    var artistViewUrl : String!
    var artworkUrl100 : String!
    var artworkUrl30 : String!
    var artworkUrl60 : String!
    var collectionExplicitness : String!
    var collectionPrice : Float!
    var country : String!
    var currency : String!
    var kind : String!
    var previewUrl : String!
    var primaryGenreName : String!
    var releaseDate : String!
    var trackCensoredName : String!
    var trackExplicitness : String!
    var trackId : Int!
    var trackName : String!
    var trackPrice : Float!
    var trackTimeMillis : Int!
    var trackViewUrl : String!
    var wrapperType : String!
    
    
    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
        artistId = dictionary["artistId"] as? Int
        artistName = dictionary["artistName"] as? String
        artistViewUrl = dictionary["artistViewUrl"] as? String
        artworkUrl100 = dictionary["artworkUrl100"] as? String
        artworkUrl30 = dictionary["artworkUrl30"] as? String
        artworkUrl60 = dictionary["artworkUrl60"] as? String
        collectionExplicitness = dictionary["collectionExplicitness"] as? String
        collectionPrice = dictionary["collectionPrice"] as? Float
        country = dictionary["country"] as? String
        currency = dictionary["currency"] as? String
        kind = dictionary["kind"] as? String
        previewUrl = dictionary["previewUrl"] as? String
        primaryGenreName = dictionary["primaryGenreName"] as? String
        releaseDate = dictionary["releaseDate"] as? String
        trackCensoredName = dictionary["trackCensoredName"] as? String
        trackExplicitness = dictionary["trackExplicitness"] as? String
        trackId = dictionary["trackId"] as? Int
        trackName = dictionary["trackName"] as? String
        trackPrice = dictionary["trackPrice"] as? Float
        trackTimeMillis = dictionary["trackTimeMillis"] as? Int
        trackViewUrl = dictionary["trackViewUrl"] as? String
        wrapperType = dictionary["wrapperType"] as? String
    }
    
    /**
     * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if artistId != nil{
            dictionary["artistId"] = artistId
        }
        if artistName != nil{
            dictionary["artistName"] = artistName
        }
        if artistViewUrl != nil{
            dictionary["artistViewUrl"] = artistViewUrl
        }
        if artworkUrl100 != nil{
            dictionary["artworkUrl100"] = artworkUrl100
        }
        if artworkUrl30 != nil{
            dictionary["artworkUrl30"] = artworkUrl30
        }
        if artworkUrl60 != nil{
            dictionary["artworkUrl60"] = artworkUrl60
        }
        if collectionExplicitness != nil{
            dictionary["collectionExplicitness"] = collectionExplicitness
        }
        if collectionPrice != nil{
            dictionary["collectionPrice"] = collectionPrice
        }
        if country != nil{
            dictionary["country"] = country
        }
        if currency != nil{
            dictionary["currency"] = currency
        }
        if kind != nil{
            dictionary["kind"] = kind
        }
        if previewUrl != nil{
            dictionary["previewUrl"] = previewUrl
        }
        if primaryGenreName != nil{
            dictionary["primaryGenreName"] = primaryGenreName
        }
        if releaseDate != nil{
            dictionary["releaseDate"] = releaseDate
        }
        if trackCensoredName != nil{
            dictionary["trackCensoredName"] = trackCensoredName
        }
        if trackExplicitness != nil{
            dictionary["trackExplicitness"] = trackExplicitness
        }
        if trackId != nil{
            dictionary["trackId"] = trackId
        }
        if trackName != nil{
            dictionary["trackName"] = trackName
        }
        if trackPrice != nil{
            dictionary["trackPrice"] = trackPrice
        }
        if trackTimeMillis != nil{
            dictionary["trackTimeMillis"] = trackTimeMillis
        }
        if trackViewUrl != nil{
            dictionary["trackViewUrl"] = trackViewUrl
        }
        if wrapperType != nil{
            dictionary["wrapperType"] = wrapperType
        }
        return dictionary
    }
    
    /**
     * NSCoding required initializer.
     * Fills the data from the passed decoder
     */
    @objc required init(coder aDecoder: NSCoder)
    {
        artistId = aDecoder.decodeObject(forKey: "artistId") as? Int
        artistName = aDecoder.decodeObject(forKey: "artistName") as? String
        artistViewUrl = aDecoder.decodeObject(forKey: "artistViewUrl") as? String
        artworkUrl100 = aDecoder.decodeObject(forKey: "artworkUrl100") as? String
        artworkUrl30 = aDecoder.decodeObject(forKey: "artworkUrl30") as? String
        artworkUrl60 = aDecoder.decodeObject(forKey: "artworkUrl60") as? String
        collectionExplicitness = aDecoder.decodeObject(forKey: "collectionExplicitness") as? String
        collectionPrice = aDecoder.decodeObject(forKey: "collectionPrice") as? Float
        country = aDecoder.decodeObject(forKey: "country") as? String
        currency = aDecoder.decodeObject(forKey: "currency") as? String
        kind = aDecoder.decodeObject(forKey: "kind") as? String
        previewUrl = aDecoder.decodeObject(forKey: "previewUrl") as? String
        primaryGenreName = aDecoder.decodeObject(forKey: "primaryGenreName") as? String
        releaseDate = aDecoder.decodeObject(forKey: "releaseDate") as? String
        trackCensoredName = aDecoder.decodeObject(forKey: "trackCensoredName") as? String
        trackExplicitness = aDecoder.decodeObject(forKey: "trackExplicitness") as? String
        trackId = aDecoder.decodeObject(forKey: "trackId") as? Int
        trackName = aDecoder.decodeObject(forKey: "trackName") as? String
        trackPrice = aDecoder.decodeObject(forKey: "trackPrice") as? Float
        trackTimeMillis = aDecoder.decodeObject(forKey: "trackTimeMillis") as? Int
        trackViewUrl = aDecoder.decodeObject(forKey: "trackViewUrl") as? String
        wrapperType = aDecoder.decodeObject(forKey: "wrapperType") as? String
    }
    
    /**
     * NSCoding required method.
     * Encodes mode properties into the decoder
     */
    @objc func encode(with aCoder: NSCoder)
    {
        if artistId != nil{
            aCoder.encode(artistId, forKey: "artistId")
        }
        if artistName != nil{
            aCoder.encode(artistName, forKey: "artistName")
        }
        if artistViewUrl != nil{
            aCoder.encode(artistViewUrl, forKey: "artistViewUrl")
        }
        if artworkUrl100 != nil{
            aCoder.encode(artworkUrl100, forKey: "artworkUrl100")
        }
        if artworkUrl30 != nil{
            aCoder.encode(artworkUrl30, forKey: "artworkUrl30")
        }
        if artworkUrl60 != nil{
            aCoder.encode(artworkUrl60, forKey: "artworkUrl60")
        }
        if collectionExplicitness != nil{
            aCoder.encode(collectionExplicitness, forKey: "collectionExplicitness")
        }
        if collectionPrice != nil{
            aCoder.encode(collectionPrice, forKey: "collectionPrice")
        }
        if country != nil{
            aCoder.encode(country, forKey: "country")
        }
        if currency != nil{
            aCoder.encode(currency, forKey: "currency")
        }
        if kind != nil{
            aCoder.encode(kind, forKey: "kind")
        }
        if previewUrl != nil{
            aCoder.encode(previewUrl, forKey: "previewUrl")
        }
        if primaryGenreName != nil{
            aCoder.encode(primaryGenreName, forKey: "primaryGenreName")
        }
        if releaseDate != nil{
            aCoder.encode(releaseDate, forKey: "releaseDate")
        }
        if trackCensoredName != nil{
            aCoder.encode(trackCensoredName, forKey: "trackCensoredName")
        }
        if trackExplicitness != nil{
            aCoder.encode(trackExplicitness, forKey: "trackExplicitness")
        }
        if trackId != nil{
            aCoder.encode(trackId, forKey: "trackId")
        }
        if trackName != nil{
            aCoder.encode(trackName, forKey: "trackName")
        }
        if trackPrice != nil{
            aCoder.encode(trackPrice, forKey: "trackPrice")
        }
        if trackTimeMillis != nil{
            aCoder.encode(trackTimeMillis, forKey: "trackTimeMillis")
        }
        if trackViewUrl != nil{
            aCoder.encode(trackViewUrl, forKey: "trackViewUrl")
        }
        if wrapperType != nil{
            aCoder.encode(wrapperType, forKey: "wrapperType")
        }
    }
}
