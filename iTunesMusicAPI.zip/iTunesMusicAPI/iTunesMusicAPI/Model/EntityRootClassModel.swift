//
//  EntityRootClassModel.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by ADMIN on 10/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import Foundation

class EntityRootClassModel : NSObject, NSCoding{
    
    var playListEntityResultModel : [PlayListEntityResultModel]!
    
    
    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
        playListEntityResultModel = [PlayListEntityResultModel]()
        if let resultsArray = dictionary["results"] as? [[String:Any]]{
            for dic in resultsArray{
                let value = PlayListEntityResultModel(fromDictionary: dic)
                playListEntityResultModel.append(value)
            }
        }
    }
    
    /**
     * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if playListEntityResultModel != nil{
            var dictionaryElements = [[String:Any]]()
            for resultsElement in playListEntityResultModel {
                dictionaryElements.append(resultsElement.toDictionary())
            }
            dictionary["results"] = dictionaryElements
        }
        return dictionary
    }
    
    /**
     * NSCoding required initializer.
     * Fills the data from the passed decoder
     */
    @objc required init(coder aDecoder: NSCoder)
    {
        playListEntityResultModel = aDecoder.decodeObject(forKey: "results") as? [PlayListEntityResultModel]
    }
    
    /**
     * NSCoding required method.
     * Encodes mode properties into the decoder
     */
    @objc func encode(with aCoder: NSCoder)
    {
        if playListEntityResultModel != nil{
            aCoder.encode(playListEntityResultModel, forKey: "results")
        }
    }
}
