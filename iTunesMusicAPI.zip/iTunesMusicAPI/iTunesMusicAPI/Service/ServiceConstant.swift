//
//  ServiceConstant.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by ADMIN on 10/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import Foundation
import UIKit

struct ServiceConstant{
    
    enum GeneralError{
        case NoDataFound
    }
    enum Error {
        case NoInternet
    }
    //https://itunes.apple.com/search?term=jackjohnson
    //MARK: - For All Server Related Keys
    struct Server{
        static let BaseUrl : String = "https://itunes.apple.com/search"
        static let kHeader = ["Content-Type" : "application/json"]
    }
    
    
}
