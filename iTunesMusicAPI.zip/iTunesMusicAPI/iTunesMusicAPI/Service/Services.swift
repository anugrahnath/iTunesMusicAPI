//
//  Services.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by ADMIN on 10/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit
import Alamofire

class Services: NSObject {
    // Can't init is singleton
    private override init() { }
    
    // MARK: Shared Instance
    static let shared = Services()
    
    
    typealias getSearchRecordsCompletion = (Any?) -> Void
    //MARK: Alamofire BaseUrl
    
    
    func getAPIIntegrationWithGetMethod(parameters :[String:Any], andUrl url :String, completion: @escaping getSearchRecordsCompletion) -> Void {
        
        if CommonFunction.shared.connectedInternetReachable() == false {
            completion(ServiceConstant.Error.NoInternet)
        } else {
            let URL : String = CommonFunction.shared.createStringURL(parameters, andBaseURL: url)
            print("Call API : " + url)
            
            Alamofire.request(URL, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: ServiceConstant.Server.kHeader)
                .responseJSON { response in
                    
                    if let json = response.result.value {
                        completion(json as AnyObject)
                    } else {
                        
                        completion(ServiceConstant.GeneralError.NoDataFound)
                    }
            }
        }
    }
    
}
