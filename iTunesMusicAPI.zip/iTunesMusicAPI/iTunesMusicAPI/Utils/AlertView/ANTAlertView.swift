//
//  ANTAlertView.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by ADMIN on 10/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit

class ANTAlertView: NSObject {
    private override init() { }
    // MARK: Shared Instance
    static let shared = ANTAlertView()
    
    
    func showAlertWith(_ title:String!, message:String!, onVC:UIViewController!) -> Void {
        let alertC = UIAlertController.init(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction.init(title: "OK", style: UIAlertAction.Style.cancel, handler: nil)
        alertC.addAction(okAction)
        onVC.present(alertC, animated: true, completion: nil)
    }
    
    func AskConfirmation (title:String, message:String, onVC : UIViewController, completion:@escaping (_ result:Bool) -> Void) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        onVC.present(alert, animated: true, completion: nil)
        
        alert.addAction(UIAlertAction(title: "Cash Data", style: .default, handler: { action in
            completion(true)
        }))
        
        alert.addAction(UIAlertAction(title: "Setting", style: .cancel, handler: { action in
            completion(false)
        }))
    }
}
