//
//  StringConstant.swift
//  iTunesMusicAPI
//
//  Created by ADMIN on 10/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import Foundation

enum StringConstant {
    static let WARNING = "Warning!"
    static let ALERT = "Alert!"
    static let SELECT_ENTITY_WARING = "Please select any kind of entity."
    static let NO_INTERNET_FOUND = "No Internet Found."
    static let LOADING_ENTITY_RECORDS = "Loading Entity Records..."
    static let LOADING_ENTITY_RECORDS_FROM_CASH = "Loading Entity Records From Cash..."
    static let ENTITY_MSG = "Entity should be character type, please enter valid entity"
    static let TRY_LATER = "No response from server ! try later"
    static let URL_INVALID = "URL invalid!"
    static let CASH_DATA_NOT_AVAILABEL = "Cash data not available."
    
}

