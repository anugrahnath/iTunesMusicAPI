//
//  DeskCVC.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by ADMIN on 10/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit

class DeskCVC: UICollectionViewCell {
    @IBOutlet weak var uiLabelKindName: UILabel!
    
}
