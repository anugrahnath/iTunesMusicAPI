//
//  DeskVC.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by ADMIN on 10/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit

class DeskVC: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var uiTextFieldSearch: UITextField!
    @IBOutlet weak var uiCollectionView: UICollectionView!
    private var deskCellReuseIdentifier = "keywordCell"
    var searchMediaTypeVC : SearchMediaTypeVC?
    var categoryArray : [String] = [String]()
    
    var screenSize: CGRect!
    var screenWidth: CGFloat!
    var screenHeight: CGFloat!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.uiTextFieldSearch?.delegate = self
        screenSize = UIScreen.main.bounds
        screenWidth = screenSize.width
        screenHeight = screenSize.height
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 5, left: 0, bottom: 5, right: 0)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        uiCollectionView!.collectionViewLayout = layout
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if  !CommonFunction.shared.isStringAnInt(string: textField.text!){
            categoryArray.append(textField.text!)
        }else{
            ANTAlertView.shared.showAlertWith(StringConstant.WARNING, message: StringConstant.ENTITY_MSG , onVC: self)
        }
        self.view.endEditing(true)
        return false
    }
    
    @IBAction func uiTouchUpinsideSelectCategory(_ sender: UIButton) {
         self.pushControllerOnSerchMediaTypeVC()
    }
    @IBAction func uiTouchUpinsideSubmitSelctedEntityAction(_ sender: Any) {
        if self.categoryArray.count > 0 {
            let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
            let controller:PlayListVC! = storyBoard.instantiateViewController(withIdentifier: "PlayListVC") as? PlayListVC
            controller.selectedEntityArray = self.categoryArray
            self.navigationController?.pushViewController(controller, animated: true)
            }else{
            ANTAlertView.shared.showAlertWith(StringConstant.WARNING, message: StringConstant.SELECT_ENTITY_WARING, onVC: self)
        }
        
    }
}

// MARK:- UICollectionView

extension DeskVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout, SearchMediaTypeCustomDelegate{
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       return self.categoryArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         let cell : DeskCVC = collectionView.dequeueReusableCell(withReuseIdentifier: deskCellReuseIdentifier, for: indexPath) as! DeskCVC
        cell.uiLabelKindName.text = self.categoryArray[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
       self.pushControllerOnSerchMediaTypeVC()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        
        return CGSize(width : 100, height: 35 )
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets
    {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    // MARK :- SearchMediaTypeCustomDelegate
    func getSearchMediaTypeCustomDelegate(selectedKindData: [String]) {
        self.categoryArray = selectedKindData
        self.uiCollectionView.reloadData()
    }
    
    // MARK :- Move controller on SearchMediaTypeVC for choose enitity
    func pushControllerOnSerchMediaTypeVC() {
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let controller:SearchMediaTypeVC! = storyBoard.instantiateViewController(withIdentifier: "SearchMediaTypeVC") as? SearchMediaTypeVC
        controller.delegate = self
        self.navigationController?.pushViewController(controller, animated: true)
    }
}

