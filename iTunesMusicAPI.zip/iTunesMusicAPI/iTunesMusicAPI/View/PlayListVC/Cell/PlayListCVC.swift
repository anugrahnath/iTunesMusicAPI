//
//  PlayListCVC.swift
//  iTunesMusicAPI
//
//  Created by ADMIN on 08/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit

class PlayListCVC: UICollectionViewCell {
    @IBOutlet weak var uiImageView: UIImageView!
    @IBOutlet weak var uiLabelTrackName: UILabel!
    
    func setContantAsPerModelData(entityModelData : EntityResultModel)  {
        if let artworkUrl = entityModelData.artworkUrl100{
            uiImageView.sd_setImage(with: URL(string: artworkUrl)!, placeholderImage: #imageLiteral(resourceName: "no-image"))
        }
        if let trackName = entityModelData.trackName{
           uiLabelTrackName.text = trackName
        }
        
    }
}
