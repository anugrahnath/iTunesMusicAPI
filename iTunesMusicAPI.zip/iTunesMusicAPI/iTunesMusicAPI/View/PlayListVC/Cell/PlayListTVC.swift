//
//  PlayListTVC.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by ADMIN on 09/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit
import SDWebImage
import AVFoundation

protocol PlayListCustomeDelegate {
    func showArtistProfileCustomeDelegate(profileURL : URL)
    func showMusicPreviewCustomeDelegate(previewURL : URL)
    func showTackOnAppleMusicCustomeDelegate(itunesMusicURL : URL)
    func playTackCustomeDelegate(player: AVPlayer, sender: UIButton)
}

class PlayListTVC: PlayListFoldingCell {
    @IBOutlet weak var uiImageViewPreview: UIImageView!
    @IBOutlet weak var uiLabelTrackName: UILabel!
    @IBOutlet weak var uiLabelGenrelName: UILabel!
    @IBOutlet weak var uiLabelCollectionName: UILabel!
    @IBOutlet weak var uiLabelArtistName: UILabel!
    
    @IBOutlet weak var uiLabelArtistNameWithTrackNameD: UILabel!
    @IBOutlet weak var uiImageViewPreviewD: ANTCustomImageView!
    @IBOutlet weak var uiLabelCollectionNameD: UILabel!
    @IBOutlet weak var uiLabelArtistNameD: UILabel!
    @IBOutlet weak var uiLabelGenrelNameWithReleaseDateD: UILabel!
    @IBOutlet weak var uiViewPreviewTrack: UIView!
    
    @IBOutlet weak var uiButtonAppleMusic: ANTCustomButton!
    @IBOutlet weak var uiButtonPreview: UIButton!
    @IBOutlet weak var uiButtonArtistFullProfile: ANTCustomButton!
    @IBOutlet weak var uiButtonPreviewTrack: UIButton!
    
    @IBOutlet weak var uiImageViewPreviewMain: UIImageView!
    
    var delegate : PlayListCustomeDelegate?
    var profileURL : URL?
    var previewURL : URL?
    var itunesMusicURL : URL?
    
    var player: AVPlayer?
    var playerLayer : AVPlayerLayer?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        foregroundView.layer.cornerRadius = 10
        foregroundView.layer.masksToBounds = true
        
        containerView.layer.cornerRadius = 10
        containerView.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    override func animationDuration(_ itemIndex: NSInteger, type _: PlayListFoldingCell.AnimationType) -> TimeInterval {
        let durations = [0.26, 0.2, 0.2]
        return durations[itemIndex]
    }
    
    @IBAction func uiTouchUpinsideListenAppleMusicAction(_ sender: UIButton) {
        delegate?.showTackOnAppleMusicCustomeDelegate(itunesMusicURL: itunesMusicURL!)
    }
    @IBAction func uiTouchUpinsidePreviewAction(_ sender: UIButton) {
        delegate?.showMusicPreviewCustomeDelegate(previewURL: previewURL!)
    }
    @IBAction func uiTouchUpinsideArtistFullProfile(_ sender: UIButton) {
        delegate?.showArtistProfileCustomeDelegate(profileURL: profileURL!)
    }
    
    @IBAction func uiTouchUpinsidePreviewTrackAction(_ sender: UIButton) {
        delegate?.playTackCustomeDelegate(player: player!, sender: sender)
    }
    // MARK :- Set data contant
    
    func setContantAsPerModelData(entityModelData : EntityResultModel) {
        
        if let trackName = entityModelData.trackName{
            uiLabelTrackName.text = trackName
            uiLabelArtistNameD.text = trackName
        }
        if let genreName = entityModelData.primaryGenreName{
            uiLabelGenrelName.text = genreName
        }
        if let trackCensoredName = entityModelData.trackCensoredName{
            uiLabelCollectionName.text = trackCensoredName
            uiLabelCollectionNameD.text = trackCensoredName
        }
        if let artistName = entityModelData.artistName{
            uiLabelArtistName.text = artistName
        }
        if let artworkUrl = entityModelData.artworkUrl100{
            uiImageViewPreview.sd_setImage(with: URL(string: artworkUrl)!, placeholderImage: #imageLiteral(resourceName: "no-image"))
            uiImageViewPreviewD.sd_setImage(with: URL(string: artworkUrl)!, placeholderImage: #imageLiteral(resourceName: "no-image"))
            uiImageViewPreviewMain.sd_setImage(with: URL(string: entityModelData.artworkUrl100)!, placeholderImage: #imageLiteral(resourceName: "no-image"))
        }
        if let trackName = entityModelData.trackName{
            uiLabelArtistNameWithTrackNameD.text = trackName + " : "
            if let artistName = entityModelData.artistName{
                uiLabelArtistNameWithTrackNameD.text = trackName + " : " + artistName
            }
        }
        if let releaseDate =  entityModelData.releaseDate{
            let albumReleaseYear = (releaseDate).components(separatedBy: "-")
            if let kind = entityModelData.kind{
                uiLabelGenrelNameWithReleaseDateD.text = kind.capitalized + " - " + albumReleaseYear[0]
            }
        }
        if let artistUrl : String = entityModelData.artistViewUrl {
            profileURL = URL(string: artistUrl)!
        }
        
        if let previewUrl : String = entityModelData.previewUrl {
            previewURL = URL(string: previewUrl)!
            player = AVPlayer(url: URL(string:previewUrl)!) // video url
            playerLayer = AVPlayerLayer(player: player)
            playerLayer!.frame = uiViewPreviewTrack.bounds
            uiViewPreviewTrack.layer.addSublayer(playerLayer!)
        }
        if let itunesMusicUrl : String = entityModelData.trackViewUrl{
            itunesMusicURL = URL(string: itunesMusicUrl)!
        }
    }
}
