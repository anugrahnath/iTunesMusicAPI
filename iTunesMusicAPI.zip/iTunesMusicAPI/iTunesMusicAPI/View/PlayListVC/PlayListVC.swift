//
//  PlayListVC.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by AnugrahNathTiwari on 08/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit
import AVKit
import NVActivityIndicatorView
import AVFoundation

class PlayListVC: UIViewController {

    @IBOutlet weak var uiCollectionView: UICollectionView!
    @IBOutlet weak var uiTableView: UITableView!
    @IBOutlet weak var uiViewCollectionMain: UIView!
    @IBOutlet weak var uiViewListViewMain: UIView!
    
    let screenSize: CGRect = UIScreen.main.bounds
    private let gridCellReuseIdentifier = "GridCell"
    var selectedEntityArray : [String] = [String]()
    
    var mainData : [NSDictionary] = [NSDictionary]()
    var customData : [String: Any] = [String: Any]()
    // Model initialization
    
    var entityRootClassBundel : EntityRootClassModel?
    var playListEntityResultModelData : [PlayListEntityResultModel] = [PlayListEntityResultModel]()
    var entityResultModel : EntityResultModel?
    var playListEntityResultModel : PlayListEntityResultModel?
    
    // defined variable for setup UI of tableview
    var flag : Int = 0
    var totalRecords : Int = 0
    
    enum Const {
        static let closeCellHeight: CGFloat = 150
        static let openCellHeight: CGFloat = 460
        static var rowsCount = 1000
    }
    
    var cellHeights: [CGFloat] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        uiViewListViewMain.frame = CGRect(x: screenSize.width, y: 0, width: screenSize.width, height: uiViewListViewMain.frame.height)
        uiViewListViewMain.isHidden = true
        
        // call service
        self.callEntityService()
    }

    // MARK:- Call service
    func callEntityService()  {
        if CommonFunction.shared.connectedInternetReachable() {
            if selectedEntityArray.count > 0{
                self.callSearchedMediaEntityServices(selectedEntity: selectedEntityArray)
            }
        }else{
            
            ANTAlertView.shared.AskConfirmation(title: StringConstant.WARNING, message: StringConstant.NO_INTERNET_FOUND, onVC: self) { (responseAlert) in
                if responseAlert{
                    let size = CGSize(width: 40, height: 40)
                    self.startAnimating(size, message: StringConstant.LOADING_ENTITY_RECORDS_FROM_CASH, type: NVActivityIndicatorType(rawValue: 12)!, color: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), fadeInAnimation: nil)
                    
                    if CommonFunction.isJSONFileExistInDocumentDirectory(fileName: "EntityResultMasterFile"){
                        
                        CommonFunction.getDataFromJSONFile(fileName: "EntityResultMasterFile") { (JSONData) in
                            
                            // setup data for model
                            self.makeEntityResultDataForModel(finalDataResponse: JSONData!)
                        }
                    }else{
                        ANTAlertView.shared.showAlertWith(StringConstant.WARNING, message: StringConstant.CASH_DATA_NOT_AVAILABEL, onVC: self)
                    }
                }else{
                    UIApplication.shared.open(URL.init(string: UIApplication.openSettingsURLString)!, options: [:], completionHandler: nil)
                    
                }
            }
        }
    }
    
    private func setup() {
        cellHeights = Array(repeating: Const.closeCellHeight, count: Const.rowsCount)
        uiTableView.estimatedRowHeight = Const.closeCellHeight
        uiTableView.rowHeight = UITableView.automaticDimension
        uiTableView.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "background"))
        uiCollectionView.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "background"))
        if #available(iOS 10.0, *) {
            uiTableView.refreshControl = UIRefreshControl()
            uiTableView.refreshControl?.addTarget(self, action: #selector(refreshHandler), for: .valueChanged)
        }
    }
    
    @objc func refreshHandler() {
        let deadlineTime = DispatchTime.now() + .seconds(1)
        DispatchQueue.main.asyncAfter(deadline: deadlineTime, execute: { [weak self] in
            if #available(iOS 10.0, *) {
                self?.uiTableView.refreshControl?.endRefreshing()
            }
            self?.uiTableView.reloadData()
        })
    }
    
    @IBAction func uiTouchupInsideBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func uiTouchupInsideGridLayoutAction(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.5, delay: 0, options: [.curveEaseIn], animations: {
        self.uiViewListViewMain.frame = CGRect(x: self.screenSize.width, y: 50, width: self.screenSize.width, height: self.uiViewListViewMain.frame.height)
        self.uiViewCollectionMain.frame = CGRect(x: 0, y: 50, width: self.screenSize.width, height: self.uiViewCollectionMain.frame.height)
        })
            
         
    }
    @IBAction func uiTouchupInsideListLayout(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.5, delay: 0, options: [.curveEaseIn], animations: {
            self.uiViewListViewMain.isHidden = false
            self.uiViewCollectionMain.frame = CGRect(x: 0 - self.screenSize.width, y: 50, width: self.screenSize.width, height: self.uiViewCollectionMain.frame.height)
             self.uiViewListViewMain.frame = CGRect(x: 0, y: 50, width: self.screenSize.width, height: self.uiViewListViewMain.frame.height)
        })
    }
}

// MARK: - CollectionView

extension PlayListVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return self.playListEntityResultModelData.count
    }
   
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        playListEntityResultModel = self.playListEntityResultModelData[section]
        
        return (playListEntityResultModel?.entityResult.count)!
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        var reusableview: PlayListCollectionReusableView? = nil
        
        if kind == UICollectionView.elementKindSectionHeader {
            playListEntityResultModel = self.playListEntityResultModelData[indexPath.section]
            
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "GridCellHeader", for: indexPath) as? PlayListCollectionReusableView
            headerView?.uiLabelSectionHeader.text = self.playListEntityResultModel?.entityName.capitalized
            
            reusableview = headerView
        }
        return reusableview!
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : PlayListCVC = collectionView.dequeueReusableCell(withReuseIdentifier: gridCellReuseIdentifier, for: indexPath) as! PlayListCVC
        
        playListEntityResultModel = self.playListEntityResultModelData[indexPath.section]
        
        cell.setContantAsPerModelData(entityModelData: (playListEntityResultModel?.entityResult[indexPath.row])!)
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        playListEntityResultModel = self.playListEntityResultModelData[indexPath.section]
        
       entityResultModel =  playListEntityResultModel?.entityResult[indexPath.row]
        if let previewUrl = entityResultModel?.previewUrl{
            self.playVideo(videoUrl: URL(string: previewUrl)!)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let width = ((screenSize.width)/2 - 20)
        return CGSize(width : width, height: width + 50 )
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets
    {
        return UIEdgeInsets(top: 0, left: 0, bottom: 5, right: 0)
    }
    
}
// MARK: - TableView

extension PlayListVC : UITableViewDelegate, UITableViewDataSource, PlayListCustomeDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
            return self.playListEntityResultModelData.count
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        playListEntityResultModel = self.playListEntityResultModelData[section]
        
        return self.playListEntityResultModel?.entityName.capitalized
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int){
        view.tintColor = UIColor.white
        
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.textColor = CommonFunction.hexStringToUIColor(hex: "F03E5F")
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_: UITableView, numberOfRowsInSection  section: Int) -> Int {
        playListEntityResultModel = self.playListEntityResultModelData[section]
        
        return (playListEntityResultModel?.entityResult.count)!
    }
    
    func tableView(_: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        guard case let cell as PlayListTVC = cell else {
            return
        }
        
        cell.backgroundColor = .clear
        
        if cellHeights[indexPath.row] == Const.closeCellHeight {
            cell.unfold(false, animated: false, completion: nil)
        } else {
            cell.unfold(true, animated: false, completion: nil)
        }
        
        cell.delegate = self
        
        playListEntityResultModel = self.playListEntityResultModelData[indexPath.section]
        
        cell.setContantAsPerModelData(entityModelData: (playListEntityResultModel?.entityResult[indexPath.row])!)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlayListFoldingCell", for: indexPath) as! PlayListFoldingCell
        
        let durations: [TimeInterval] = [0.26, 0.2, 0.2]
        cell.durationsForExpandedState = durations
        cell.durationsForCollapsedState = durations
        
        
        return cell
    }
    
    func tableView(_: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeights[indexPath.row]
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: indexPath) as! PlayListFoldingCell
        
        if cell.isAnimating() {
            return
        }
        
        var duration = 0.0
        let cellIsCollapsed = cellHeights[indexPath.row] == Const.closeCellHeight
        if cellIsCollapsed {
            cellHeights[indexPath.row] = Const.openCellHeight
            cell.unfold(true, animated: true, completion: nil)
            duration = 0.5
        } else {
            cellHeights[indexPath.row] = Const.closeCellHeight
            cell.unfold(false, animated: true, completion: nil)
            duration = 0.8
        }
        
        UIView.animate(withDuration: duration, delay: 0, options: .curveEaseOut, animations: { () -> Void in
            tableView.beginUpdates()
            tableView.endUpdates()
        }, completion: nil)
        
    }
    
    
    // MARk :- PlaylistCustomDelegate
    
    func showArtistProfileCustomeDelegate(profileURL: URL) {
        if let urlProfile : URL = profileURL{
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(urlProfile, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(urlProfile)
            }
        }else{
            ANTAlertView.shared.showAlertWith(StringConstant.WARNING, message: ("Profile \(StringConstant.URL_INVALID)"), onVC: self)
        }
        
       
    }
    
    func showMusicPreviewCustomeDelegate(previewURL: URL) {
        if let urlPreview : URL = previewURL{
        self.playVideo(videoUrl: urlPreview)
        }else{
            ANTAlertView.shared.showAlertWith(StringConstant.WARNING, message: ("Preview \(StringConstant.URL_INVALID)"), onVC: self)
        }
    }
    
    func showTackOnAppleMusicCustomeDelegate(itunesMusicURL: URL) {
        if let urliTunesMusic : URL = itunesMusicURL{
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(urliTunesMusic, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(urliTunesMusic)
            }
        }else{
            ANTAlertView.shared.showAlertWith(StringConstant.WARNING, message: ("iTunes Music \(StringConstant.URL_INVALID)"), onVC: self)
        }
    }
    
    func playTackCustomeDelegate(player: AVPlayer, sender : UIButton) {
        sender.isSelected = !sender.isSelected
        if sender.isSelected {
            player.play()
        }else{
            player.pause()
        }
        
    }
}
extension PlayListVC : NVActivityIndicatorViewable {
    func callSearchedMediaEntityServices(selectedEntity : [String]) {
        let size = CGSize(width: 40, height: 40)
        self.startAnimating(size, message: StringConstant.LOADING_ENTITY_RECORDS, type: NVActivityIndicatorType(rawValue: 29)!, color: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), fadeInAnimation: nil)
        
        for entityName in selectedEntity {
            let parameters : [String : String] = ["term" : "jackjohnson", "entity" : entityName]
            ServicesController.shared.GetSearchedEntityRecords(parameter: parameters, andURL: ServiceConstant.Server.BaseUrl) { (response) in
               // print(response)
                if response is ServiceConstant.GeneralError{
                    Toast.init(text: StringConstant.TRY_LATER).show()
                }
                else if response is Error{
                    ANTAlertView.shared.showAlertWith(StringConstant.WARNING, message: StringConstant.NO_INTERNET_FOUND, onVC: self)
                }
                else{
                    let responseDict = response as? NSDictionary
                    if responseDict != nil{ 
                        
                        if let errorMassage = responseDict!["errorMessage"] as? String {
                            Toast.init(text: errorMassage).show()
                        }else{
                            
                            self.customData = [
                                "entityName": entityName,
                                "entityResult": responseDict!["results"] as! [NSDictionary]
                            ]
                            
                            self.mainData.append(self.customData as NSDictionary)
                            
                            let finalData : NSMutableDictionary = NSMutableDictionary()
                            finalData.setValue(self.mainData, forKey: "results")
                    
                            // setup data for model
                            self.makeEntityResultDataForModel(finalDataResponse: finalData)
                            
                            // responses have been saved in JSON file to maintain cash
                            CommonFunction.saveDataToJsonFile(data: finalData as NSDictionary, fileName: "EntityResultMasterFile")
                            
                        }
                        
                    }
                }
            }
           
        }
    }
    
    // MARK:- here, Data response are populated for model class
    
    func makeEntityResultDataForModel(finalDataResponse: NSDictionary) {
        
        self.entityRootClassBundel = EntityRootClassModel.init(fromDictionary: finalDataResponse as! [String : Any] )
        self.playListEntityResultModelData = (self.entityRootClassBundel?.playListEntityResultModel)!
        
        // Configure tableview layout
        self.playListEntityResultModel = self.playListEntityResultModelData[self.flag]
        
        
        
        self.setup()
        self.uiTableView.reloadData()
        self.uiCollectionView.reloadData()
        
        self.flag += 1
        
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
            self.stopAnimating(nil)
        }
    }
}

extension PlayListVC {
    func playVideo(videoUrl : URL)  {
        
        let player = AVPlayer(url: videoUrl)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
    }
}
}
