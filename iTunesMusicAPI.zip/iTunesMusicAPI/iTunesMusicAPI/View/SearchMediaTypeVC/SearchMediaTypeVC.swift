//
//  SearchMediaTypeVC.swift
//  iTunesMusicAPI
//  anugrah.nath6@gmail.com
//  Created by ADMIN on 10/02/19.
//  Copyright © 2019 AnugrahNathTiwari. All rights reserved.
//

import UIKit
protocol SearchMediaTypeCustomDelegate {
    func getSearchMediaTypeCustomDelegate(selectedKindData : [String])
}
class SearchMediaTypeVC: UIViewController {

    @IBOutlet weak var uiTableView: UITableView!
    
    var mediaType : [String] = [String]()
    var mediaKey : [String] = [String]()
    var selectedMediaType : [String] = [String]()
    
    var delegate : SearchMediaTypeCustomDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

       self.mediaType = ["Album", "Artist", "Book", "Movie", "Music Video","Podcast", "Song"]
        
        self.mediaKey = ["album", "artist", "book", "movie", "musicVideo","podcast", "song"]
        
        // Do any additional setup after loading the view.
    }
    

    @IBAction func uiTouchupInsideBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func uiTouchupInsideDoneAction(_ sender: Any) {
        if selectedMediaType.count > 0 { 
            delegate?.getSearchMediaTypeCustomDelegate(selectedKindData: self.selectedMediaType)
            self.navigationController?.popViewController(animated: true)
        }else{
            ANTAlertView.shared.showAlertWith(StringConstant.ALERT, message: StringConstant.SELECT_ENTITY_WARING, onVC: self)
        }
        
    }
    
}
extension SearchMediaTypeVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  self.mediaType.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : SearchMediaTypeTVC =  tableView.dequeueReusableCell(withIdentifier: "SearchMediaTypeTVC", for: indexPath) as! SearchMediaTypeTVC
        cell.uiLabelMediaTypeName.text = mediaType[indexPath.row]
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         
        if let cell = tableView.cellForRow(at: indexPath) {
            cell.accessoryType = .checkmark
            self.selectedMediaType.append(self.mediaKey[indexPath.row])
            print(self.selectedMediaType)
        }
        
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        
        if let cell = tableView.cellForRow(at: indexPath) {
            cell.accessoryType = .none
            if let index = self.selectedMediaType.index(of: self.mediaKey[indexPath.row]) {
                self.selectedMediaType.remove(at: index)
            }
            print(self.selectedMediaType)
        }
        
    }
    
    
}
